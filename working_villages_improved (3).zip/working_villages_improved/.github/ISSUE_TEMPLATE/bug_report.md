---
name: Bug report
about: Report a crash or incorrect behaviour
title: '[BUG] '
labels: bug
assignees: ''
---

## Describe the bug
A clear description of what the bug is.

## Steps to reproduce
1. Assign villager job '...'
2. Place chest at '...'
3. See error

## Expected behaviour
What you expected to happen.

## Error message
Paste the full error from the Luanti/Minetest log or the in-game error overlay.

```
paste error here
```

## Environment
- **Luanti / Minetest version**: e.g. 5.14.0
- **Other active mods**: e.g. animalia, farming, technic_plus
- **World seed** (if relevant):

## Screenshots
If applicable, add screenshots to help explain the problem.
