---
name: Feature request
about: Suggest a new job, improvement, or feature
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

## Summary
A short description of the feature you want.

## Motivation
Why would this be useful? What problem does it solve?

## Proposed behaviour
Describe in detail how this feature would work.

## Alternatives considered
Any other approaches you considered.

## Additional context
Any other notes, screenshots, or links.
