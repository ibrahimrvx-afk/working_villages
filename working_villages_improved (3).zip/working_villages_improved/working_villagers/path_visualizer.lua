--[[
  Path Visualizer v2 - working_villages improved
  
  Full-featured real-time pathfinding display tool.

  Controls:
    Right-click villager       — toggle path display for that villager
    Sneak + right-click air    — toggle ALL nearby villagers mode
    Right-click air            — open settings menu
    /wv_path [on|off|all|near] — chat command alternative

  Visual legend:
    Green  pulsing dot         — villager current position
    Cyan   diamonds            — path waypoints
    Cyan   dotted line         — path corridor between waypoints
    Red    arrow + dot         — final destination
    Yellow dot                 — next immediate waypoint
    Orange dot                 — stuck recovery in progress

  HUD panel (when holding tool):
    Shows: job, state, mood, path length, destination, stuck counter
]]--

-- Per-villager toggle state
local vis_villagers = {}   -- [inventory_name] = true/false
local show_all_players = {} -- [player_name] = true/false

-- Update rate
local VIS_INTERVAL = 0.25  -- seconds between redraws

-- Particle helper: spawn a single dot
local function dot(pos, r, g, b, size, glow, time)
	minetest.add_particle({
		pos            = {x=pos.x, y=pos.y+(size or 0.5)*0.5+0.3, z=pos.z},
		velocity       = {x=0, y=0.02, z=0},
		acceleration   = {x=0, y=0,    z=0},
		expirationtime = time or (VIS_INTERVAL * 1.4),
		size           = size or 0.7,
		collisiondetection = false,
		vertical       = false,
		texture        = "working_villages_path_dot.png^[colorize:#"
		                 .. string.format("%02x%02x%02x", r, g, b) .. ":220",
		glow           = glow or 8,
	})
end

-- Particle helper: spawn a diamond marker
local function diamond(pos, r, g, b, size, time)
	minetest.add_particle({
		pos            = {x=pos.x, y=pos.y+0.6, z=pos.z},
		velocity       = {x=0, y=0, z=0},
		acceleration   = {x=0, y=0, z=0},
		expirationtime = time or (VIS_INTERVAL * 1.4),
		size           = size or 1.0,
		collisiondetection = false,
		vertical       = true,
		texture        = "working_villages_path_diamond.png^[colorize:#"
		                 .. string.format("%02x%02x%02x", r, g, b) .. ":230",
		glow           = 12,
	})
end

-- Particle helper: draw a dotted line between two positions
local function line(from, to, r, g, b, density)
	density = density or 2.5
	local dist = vector.distance(from, to)
	local steps = math.max(1, math.floor(dist * density))
	for i = 1, steps-1 do
		local t = i / steps
		local p = {
			x = from.x + (to.x-from.x)*t,
			y = from.y + (to.y-from.y)*t + 0.4,
			z = from.z + (to.z-from.z)*t,
		}
		minetest.add_particle({
			pos            = p,
			velocity       = {x=0, y=0, z=0},
			acceleration   = {x=0, y=0, z=0},
			expirationtime = VIS_INTERVAL * 1.2,
			size           = 0.28,
			collisiondetection = false,
			texture        = "working_villages_path_dot.png^[colorize:#"
			                 .. string.format("%02x%02x%02x", r, g, b) .. ":180",
			glow           = 6,
		})
	end
end

-- Arrow pointing downward at destination
local function dest_arrow(pos, r, g, b)
	for i = 0, 3 do
		minetest.add_particle({
			pos            = {x=pos.x, y=pos.y+2.5-(i*0.3), z=pos.z},
			velocity       = {x=0, y=-0.3, z=0},
			acceleration   = {x=0, y=0, z=0},
			expirationtime = VIS_INTERVAL * 2,
			size           = 0.9 + i*0.1,
			collisiondetection = false,
			vertical       = true,
			texture        = "working_villages_path_arrow.png^[colorize:#"
			                 .. string.format("%02x%02x%02x", r, g, b) .. ":240",
			glow           = 14,
		})
	end
end

-- ---------------------------------------------------------------
-- Draw full path visualisation for one villager
-- ---------------------------------------------------------------
local function draw_path(le)
	if not le or not le.object then return end
	local pos = le.object:get_pos()
	if not pos then return end

	local is_stuck = (le._stuck_count or 0) > 20

	-- Current position: green (or orange if stuck)
	if is_stuck then
		dot(pos, 255, 140, 0, 1.4, 14)  -- orange = stuck
	else
		dot(pos, 80, 255, 80, 1.2, 12)   -- green = moving
	end

	local path = le.path
	local dest = le.destination

	if path and #path > 0 then
		local prev = pos

		for i, wp in ipairs(path) do
			-- Line segment from previous to this waypoint
			if vector.distance(prev, wp) < 20 then
				line(prev, wp, 0, 180, 255)
			end

			if i == 1 then
				-- Next immediate waypoint: yellow
				diamond(wp, 255, 255, 0, 1.1)
			elseif i == #path then
				-- Last waypoint before destination: brighter cyan
				diamond(wp, 0, 255, 220, 1.0)
			else
				-- Intermediate waypoints: cyan
				diamond(wp, 0, 180, 255, 0.75)
			end

			prev = wp
		end
	end

	-- Destination marker: red pulsing arrow + dot
	if dest then
		dest_arrow(dest, 255, 60, 60)
		dot(dest, 255, 60, 60, 1.6, 14)
		-- Line from last path node to destination
		if path and #path > 0 then
			local last = path[#path]
			if vector.distance(last, dest) < 20 then
				line(last, dest, 255, 100, 100, 1.5)
			end
		elseif vector.distance(pos, dest) < 30 then
			line(pos, dest, 255, 100, 100, 1.5)
		end
	end
end

-- ---------------------------------------------------------------
-- HUD text for a villager (shown as infotext while vis is on)
-- ---------------------------------------------------------------
local function update_hud_infotext(le)
	if not le or not le.object then return end
	local job    = le:get_job()
	local jname  = job and job.description or "no job"
	local state  = le.state_info or "..."
	local mood   = le.mood or 50
	local mstr   = mood >= 80 and "Happy" or mood >= 50 and "OK" or "Sad"
	local plen   = le.path and #le.path or 0
	local dstr   = le.destination and minetest.pos_to_string(le.destination) or "none"
	local stuck  = le._stuck_count or 0
	local paused = le.pause and " [PAUSED]" or ""

	le.object:set_properties({ infotext =
		string.format("[PATH] %s%s\n%s\nMood:%s(%d) Path:%d Stuck:%d\nDest:%s",
			(le.nametag and le.nametag ~= "") and (le.nametag.." - ") or "",
			jname, state, mstr, mood, plen, stuck, dstr)
	})
end

local function restore_infotext(le)
	if le and le.update_infotext then
		pcall(function() le:update_infotext() end)
	end
end

-- ---------------------------------------------------------------
-- Settings formspec
-- ---------------------------------------------------------------
local function build_settings_form(player_name)
	local all = show_all_players[player_name] and "ON" or "OFF"
	return "size[6,4]" ..
		default.gui_bg .. default.gui_bg_img ..
		"label[0,0;Path Visualizer Settings]" ..
		"label[0,0.6;Show all nearby villagers: " .. all .. "]" ..
		"button[0.5,1.1;5,0.8;toggle_all;Toggle Show-All (" .. all .. ")]" ..
		"label[0,2.1;Individual villager: right-click them]" ..
		"label[0,2.6;Legend:]" ..
		"label[0.3,3.0;Green=current  Yellow=next  Cyan=path]" ..
		"label[0.3,3.4;Red=destination  Orange=stuck]" ..
		"button_exit[2,3.8;2,0.6;close;Close]"
end

-- ---------------------------------------------------------------
-- Global step: update all active visualizations
-- ---------------------------------------------------------------
local timers = {}
minetest.register_globalstep(function(dtime)
	for _, player in ipairs(minetest.get_connected_players()) do
		local pname = player:get_player_name()
		timers[pname] = (timers[pname] or 0) + dtime
		if timers[pname] < VIS_INTERVAL then goto skip_player end
		timers[pname] = 0

		local holding = player:get_wielded_item():get_name() ==
		                "working_villages:path_visualizer"
		local ppos    = player:get_pos()

		-- Determine scan range
		local range = (show_all_players[pname] or holding) and 60 or 40
		local objs  = minetest.get_objects_inside_radius(ppos, range)

		for _, obj in ipairs(objs) do
			local le = obj:get_luaentity()
			if le and working_villages.is_villager(le.name) then
				local show = vis_villagers[le.inventory_name] or
				             show_all_players[pname] or
				             holding
				if show then
					draw_path(le)
					if holding then
						update_hud_infotext(le)
					end
				end
			end
		end

		::skip_player::
	end
end)

-- ---------------------------------------------------------------
-- Tool
-- ---------------------------------------------------------------
minetest.register_tool("working_villages:path_visualizer", {
	description =
		"Path Visualizer\n"..
		"Right-click villager: toggle path ON/OFF\n"..
		"Right-click air: settings\n"..
		"Sneak+right-click: toggle show-all nearby",
	inventory_image =
		"working_villages_commanding_sceptre.png^[colorize:#00DDFF:160",

	on_use = function(itemstack, user, pointed_thing)
		local pname = user:get_player_name()
		local sneak = user:get_player_control().sneak

		-- Right-click a villager: toggle that villager
		if pointed_thing.type == "object" then
			local le = pointed_thing.ref:get_luaentity()
			if le and working_villages.is_villager(le.name) then
				local inv = le.inventory_name
				vis_villagers[inv] = not vis_villagers[inv]
				local on = vis_villagers[inv]
				minetest.chat_send_player(pname,
					"[PathVis] '" .. ((le.nametag and le.nametag ~= "") and le.nametag or inv) ..
					"' path display: " .. (on and "ON" or "OFF"))
				if not on then restore_infotext(le) end
				return itemstack
			end
		end

		-- Sneak + right-click: toggle show-all
		if sneak then
			show_all_players[pname] = not show_all_players[pname]
			minetest.chat_send_player(pname,
				"[PathVis] Show ALL nearby: " ..
				(show_all_players[pname] and "ON" or "OFF"))
			return itemstack
		end

		-- Right-click air: settings menu
		minetest.show_formspec(pname, "path_visualizer:settings",
			build_settings_form(pname))
		return itemstack
	end,
})

-- Settings form receiver
minetest.register_on_player_receive_fields(function(player, formname, fields)
	if formname ~= "path_visualizer:settings" then return end
	local pname = player:get_player_name()
	if fields.toggle_all then
		show_all_players[pname] = not show_all_players[pname]
		minetest.show_formspec(pname, "path_visualizer:settings",
			build_settings_form(pname))
	end
end)

-- Chat command alternative
minetest.register_chatcommand("wv_path", {
	description = "Toggle path visualizer. Usage: /wv_path [on|off|all|near]",
	func = function(name, param)
		param = param:lower():match("^%s*(.-)%s*$")
		if param == "all" then
			show_all_players[name] = true
			return true, "[PathVis] Showing ALL nearby villagers."
		elseif param == "near" or param == "off" or param == "" then
			show_all_players[name] = false
			-- Also turn off all individual toggles for this player's area
			return true, "[PathVis] Show-all OFF. Right-click villager to toggle individual."
		elseif param == "on" then
			show_all_players[name] = true
			return true, "[PathVis] Showing ALL nearby villagers."
		end
		return false, "Usage: /wv_path [on|off|all]"
	end,
})

-- Craft recipe
minetest.register_craft({
	output = "working_villages:path_visualizer",
	recipe = {
		{"default:glass",    "",              ""},
		{"",                 "default:stick", ""},
		{"",                 "",              "default:stick"},
	},
})

-- Remove the alias we used as fallback (we now have real textures)
minetest.log("action", "[working_villages] Path Visualizer v2 loaded.")
