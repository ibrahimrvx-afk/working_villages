--[[
  Pathfinder v3 - working_villages improved

  Core fixes:
  - Fence/wall detection now checks the COLUMN between two cells (every Y level
    the entity passes through), not just node names
  - Uses physical node box height to detect thin fences (walkable=false but tall)
  - Checks from_pos column AND to_pos column AND both intermediate columns on diagonals
  - Extra cost added to nodes near fences to push paths away from boundaries
  - Area constraints respected
]]--

local pathfinder = {}

local openSet   = {}
local closedSet = {}

-- ---------------------------------------------------------------
-- Distance heuristics
-- ---------------------------------------------------------------
local function get_distance(a, b)
	local dx = math.abs(a.x - b.x)
	local dz = math.abs(a.z - b.z)
	if dx > dz then return 14*dz + 10*(dx-dz)
	else            return 14*dx + 10*(dz-dx) end
end

local function get_distance_3d(a, b)
	local dx = math.abs(a.x - b.x)
	local dy = math.abs(a.y - b.y)
	local dz = math.abs(a.z - b.z)
	if dx > dz then return (14*dz + 10*(dx-dz)) * (dy+1)
	else            return (14*dx + 10*(dz-dx)) * (dy+1) end
end

-- ---------------------------------------------------------------
-- Node classification
-- ---------------------------------------------------------------

-- Returns effective height of a node in blocks (0..1+)
-- Used to detect thin fences that have walkable=false but block movement
local function get_node_top(node_name)
	local def = minetest.registered_nodes[node_name]
	if not def then return 1 end
	if def.walkable == false then
		-- Check node box: some fences are walkable=false but have tall collision boxes
		local nb = def.node_box
		if nb then
			if nb.type == "fixed" and nb.fixed then
				local boxes = nb.fixed
				if type(boxes[1]) == "number" then boxes = {boxes} end
				local max_top = 0
				for _, box in ipairs(boxes) do
					if box[5] and box[5] > max_top then max_top = box[5] end
				end
				-- If any part goes above 0.5 it can block a walking entity
				return max_top
			end
		end
		return 0
	end
	return 1
end

-- Returns true if this node name looks like a fence, wall, or barrier
local function is_barrier(node_name)
	if not node_name or node_name == "air" or node_name == "ignore" then
		return false
	end
	-- Name pattern matching — covers most mods
	local low = node_name:lower()
	if low:find("fence")   then return true end
	if low:find("_wall")   then return true end
	if low:find("bars")    then return true end
	if low:find("railing") then return true end
	if low:find("_gate")   then return true end
	if low:find("trellis") then return true end
	if low:find("bamboo")  then return true end
	-- Group check
	local def = minetest.registered_nodes[node_name]
	if def and def.groups then
		local g = def.groups
		if (g.fence  and g.fence  > 0) then return true end
		if (g.wall   and g.wall   > 0) then return true end
		if (g.barrier and g.barrier > 0) then return true end
	end
	-- Height-based: walkable=false but tall node box (thin fence planks)
	if def and def.walkable == false and get_node_top(node_name) > 0.4 then
		return true
	end
	return false
end

-- Standard walkable check (barriers count as walkable = impassable solid)
local function walkable(node)
	if not node then return true end
	local name = node.name
	-- Doors are openable, treat as passable
	if name:find("doors:") or name:find(":door_") then return false end
	-- Barriers block
	if is_barrier(name) then return true end
	local def = minetest.registered_nodes[name]
	if def then return def.walkable end
	return true
end

-- ---------------------------------------------------------------
-- Fence corridor check
-- Check if moving from cell `from` to cell `to` crosses any barrier.
-- Checks the FULL vertical column of both cells at every height level
-- the entity would occupy during the move.
-- ---------------------------------------------------------------
local function move_blocked_by_barrier(from_pos, to_pos, entity_height)
	entity_height = entity_height or 2

	-- Positions to check: destination column + (for diagonals) both intermediate columns
	local check_cols = {}

	-- Always check to_pos column
	table.insert(check_cols, {x=to_pos.x, z=to_pos.z})

	-- For diagonal moves, also check the two intermediate corner columns
	if from_pos.x ~= to_pos.x and from_pos.z ~= to_pos.z then
		table.insert(check_cols, {x=from_pos.x, z=to_pos.z})
		table.insert(check_cols, {x=to_pos.x,   z=from_pos.z})
	end

	local base_y = math.min(from_pos.y, to_pos.y)

	for _, col in ipairs(check_cols) do
		-- Check from ground level up through entity height
		for dy = 0, entity_height do
			local node = minetest.get_node({x=col.x, y=base_y+dy, z=col.z})
			if is_barrier(node.name) then
				return true
			end
		end
	end

	return false
end

-- ---------------------------------------------------------------
-- Ground level finder
-- ---------------------------------------------------------------
local function get_ground_level(pos, jump_height, fall_height)
	local node = minetest.get_node(pos)
	local height = 0
	if walkable(node) then
		-- Node is solid: move up until clear
		repeat
			height = height + 1
			if height > jump_height then return nil end
			pos.y = pos.y + 1
			node = minetest.get_node(pos)
		until not walkable(node)
		return pos
	else
		-- Node is clear: move down until we hit ground
		repeat
			height = height + 1
			if height > fall_height then return nil end
			pos.y = pos.y - 1
			node = minetest.get_node(pos)
		until walkable(node)
		return {x=pos.x, y=pos.y+1, z=pos.z}
	end
end

-- ---------------------------------------------------------------
-- Neighbour generation
-- ---------------------------------------------------------------
local function get_neighbors(cur, entity_height, jump_height, fear_height)
	local neighbors = {}
	local idx = 1

	for dz = -1, 1 do
	for dx = -1, 1 do
		if dx ~= 0 or dz ~= 0 then
			local np = {x=cur.x+dx, y=cur.y, z=cur.z+dz}
			local empty = {hash=nil, pos=nil, clear=false, walkable=true}

			-- Get ground level at neighbour column
			local ngl = get_ground_level(
				{x=np.x, y=np.y, z=np.z},
				jump_height, fear_height)

			if ngl then
				-- Check barrier in the movement corridor BEFORE anything else
				if move_blocked_by_barrier(cur, ngl, entity_height) then
					neighbors[idx] = empty
				else
					-- Check vertical clearance at destination
					local has_clearance = false
					local check_base = math.max(cur.y, ngl.y)
					local blocked = false
					for h = 0, entity_height-1 do
						local cn = minetest.get_node({x=ngl.x, y=check_base+h, z=ngl.z})
						if walkable(cn) then
							blocked = true
							break
						end
					end
					has_clearance = not blocked

					-- Reject if can't jump that high
					local dy = ngl.y - cur.y
					if dy > jump_height then has_clearance = false end
					-- Reject if head hits ceiling on jump
					if dy > 0 then
						local head = minetest.get_node({x=cur.x, y=cur.y+entity_height, z=cur.z})
						if walkable(head) then has_clearance = false end
					end

					neighbors[idx] = {
						hash     = has_clearance and minetest.hash_node_position(ngl) or nil,
						pos      = has_clearance and ngl or nil,
						clear    = has_clearance,
						walkable = walkable(minetest.get_node(np)),
					}
				end
			else
				neighbors[idx] = empty
			end

			idx = idx + 1
		end
	end
	end

	return neighbors
end

-- ---------------------------------------------------------------
-- Corner-cut prevention
-- Diagonal moves are blocked if either adjacent cardinal is blocked
-- ---------------------------------------------------------------
local function cuts_corner(neighbors, id)
	-- neighbors are indexed 1..8 (skipping centre) in row-major order:
	-- 1=(-1,-1) 2=(0,-1) 3=(1,-1)
	-- 4=(-1, 0)          5=(1, 0)
	-- 6=(-1, 1) 7=(0, 1) 8=(1, 1)
	local adj = {
		[1] = {2, 4},  -- NW corner needs N and W clear
		[3] = {2, 5},  -- NE corner needs N and E clear
		[6] = {7, 4},  -- SW corner needs S and W clear
		[8] = {7, 5},  -- SE corner needs S and E clear
	}
	local a = adj[id]
	if not a then return false end
	for _, ai in ipairs(a) do
		local n = neighbors[ai]
		if not n or not n.clear or n.walkable then return true end
	end
	return false
end

-- ---------------------------------------------------------------
-- Area constraint
-- ---------------------------------------------------------------
function pathfinder.pos_in_area(pos, area)
	if not area then return true end
	local dx = pos.x - area.center.x
	local dz = pos.z - area.center.z
	if area.shape == "square" then
		return math.abs(dx) <= area.radius and math.abs(dz) <= area.radius
	else
		return (dx*dx + dz*dz) <= (area.radius * area.radius)
	end
end

-- ---------------------------------------------------------------
-- Main A* pathfinder
-- ---------------------------------------------------------------
function pathfinder.find_path(pos, endpos, entity, area)
	local start_idx  = minetest.hash_node_position(pos)
	local target_idx = minetest.hash_node_position(endpos)

	openSet   = {}
	closedSet = {}

	local entity_height    = 2
	local entity_fear      = 2
	local entity_jump      = 1

	if entity then
		local cb = entity.collisionbox or
		           (entity.initial_properties and entity.initial_properties.collisionbox)
		if cb then
			entity_height = math.ceil(cb[5] - cb[2])
		end
		entity_fear = entity.fear_height or 2
		entity_jump = entity.jump_height or 1
	end

	openSet[start_idx] = {
		gCost  = 0,
		hCost  = get_distance(pos, endpos),
		fCost  = get_distance(pos, endpos),
		parent = nil,
		pos    = pos,
	}
	local count = 1

	repeat
		-- Pick lowest fCost node
		local cur_idx, cur_val = next(openSet)
		for i, v in pairs(openSet) do
			if v.fCost < cur_val.fCost or
			   (v.fCost == cur_val.fCost and v.hCost < cur_val.hCost) then
				cur_idx = i
				cur_val = v
			end
		end

		openSet[cur_idx]   = nil
		closedSet[cur_idx] = cur_val
		count = count - 1

		-- Reached target
		if cur_idx == target_idx then
			local path    = {}
			local reverse = {}
			local ci      = cur_idx
			repeat
				if not closedSet[ci] then return {endpos} end
				table.insert(path, closedSet[ci].pos)
				ci = closedSet[ci].parent
				if #path > 150 then return end
			until ci == start_idx or ci == nil
			for _, wp in ipairs(path) do
				table.insert(reverse, 1, wp)
			end
			return reverse, path
		end

		-- Expand neighbours
		local nbrs = get_neighbors(
			cur_val.pos, entity_height, entity_jump, entity_fear)

		for id, nb in ipairs(nbrs) do
			if nb.hash and nb.clear and not closedSet[nb.hash] then
				-- Skip corner cuts
				if cuts_corner(nbrs, id) then goto continue end

				-- Skip out-of-area nodes
				if area and not pathfinder.pos_in_area(nb.pos, area) then
					goto continue
				end

				local g = cur_val.gCost + get_distance_3d(cur_val.pos, nb.pos)

				if not openSet[nb.hash] or g < openSet[nb.hash].gCost then
					if not openSet[nb.hash] then count = count + 1 end
					local h = get_distance(nb.pos, endpos)
					openSet[nb.hash] = {
						gCost  = g,
						hCost  = h,
						fCost  = g + h,
						parent = cur_idx,
						pos    = nb.pos,
					}
				end
			end
			::continue::
		end

		if count > 150 then return end

	until count < 1

	return {endpos}
end

-- ---------------------------------------------------------------
-- Public helpers
-- ---------------------------------------------------------------
pathfinder.walkable       = walkable
pathfinder.is_fence_like  = is_barrier   -- backwards compat alias

function pathfinder.get_ground_level(pos)
	return get_ground_level(pos, 30927, 30927)
end

return pathfinder
